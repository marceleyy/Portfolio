// Liste des images (mettre le nom exact des fichiers)
const images = [
    { src: "images/site4.png", discipline: "Natation", info: "Finale 10m plateforme (H) | Plongeon | Jeux Olympiques de Paris 2024" },
    { src: "images/site5.jpg", discipline: "Cyclisme", info: "Finales omnium (F) | Cyclisme sur piste | Jeux Olympiques de Paris 2024" },
    { src: "images/site6.jpg", discipline: " Lutte", info: "Finale lutte libre 97kg (H) | Lutte | Jeux Olympiques de Paris 2024" },
    { src: "images/site7.jpg", discipline: "Marathon (F)", info: "Marathon (F) | Athlétisme | Jeux Olympiques de Paris 2024" },
    { src: "images/site8.jpg", discipline: "Finale 75kg (F)", info: "Finale 75kg (F) | Boxe | Jeux Olympiques de Paris 2024" },
    { src: "images/site9.jpg", discipline: "Finale +92kg (H)", info: "Finale +92kg (H) | Boxe | Jeux Olympiques de Paris 2024" },
    { src: "images/site10.jpg", discipline: "SWE-GER - Finale (H)", info: "SWE-GER - Finale (H) | Volleyball de plage | Jeux Olympiques de Paris 2024" },
    { src: "images/site11.jpg", discipline: "FRA v USA - Finale (H)", info: "FRA v USA - Finale (H) | Basketball | Jeux Olympiques de Paris 2024" },
    { src: "images/site12.jpg", discipline: "Breaking", info: "Final (H) | Breaking | Jeux Olympiques de Paris 2024" },
    { src: "images/site13.jpg", discipline: "Volleyball de plage (H)", info: "QAT-NOR - Petite finale (H) | Volleyball de plage | Jeux Olympiques de Paris 2024" },
    { src: "images/site14.jpg", discipline: "Athlétisme (F)", info: "Finale relais 4x400m (F) | Athlétisme | Jeux Olympiques de Paris 2024" },
    { src: "images/site15.jpg", discipline: "Handball", info: "GER v DEN - Finale (H) | Handball | Jeux Olympiques de Paris 2024" },
    { src: "images/site16.jpg", discipline: "Cyclisme sur piste (F)", info: "Finale sprint (F) | Cyclisme sur piste | Jeux Olympiques de Paris 2024" },
    { src: "images/site18.jpg", discipline: " Basketball", info: "BEL v AUS - Petite finale (F) | Basketball | Jeux Olympiques de Paris 2024" },
    { src: "images/site19.jpg", discipline: "Pentathlon moderne (F)", info: "Finale (F) | Pentathlon moderne | Jeux Olympiques de Paris 2024" },
    { src: "images/site20.jpg", discipline: "Water-polo", info: "USA v HUN - Petite finale (H) | Water-polo | Jeux Olympiques de Paris 2024" },
    { src: "images/site23.jpg", discipline: "TTaekwondo (H)", info: "Finales 80kg (H) | Taekwondo | Jeux Olympiques de Paris 2024" },
    { src: "images/site21.jpg", discipline: "Canoë sprint(H)", info: "Demi-finales et finale K-1 1000m (H) | Canoë sprint | Jeux Olympiques de Paris 2024" },
    { src: "images/site22.jpg", discipline: "Golf (F)", info: "Stroke play individuel (F) - Dernier tour | Golf | Jeux Olympiques de Paris 2024" },
    { src: "images/site24.jpg", discipline: "Haltérophilie", info: "Finale 71kg (F) | Haltérophilie | Jeux Olympiques de Paris 2024" },
    { src: "images/site25.jpg", discipline: "Escalade sportive", info: "Finales bloc et difficulté (H) | Escalade sportive | Jeux Olympiques de Paris 2024" },
    { src: "images/site26.jpg", discipline: "Tennis de table", info: "SWE v CHN - Petite finale par équipe (H) | Tennis de table | Jeux Olympiques de Paris 2024" },
    { src: "images/site27.jpg", discipline: "Lutte gréco-romaine", info: "Finales 87kg (H) | Lutte gréco-romaine | Jeux Olympiques de Paris 2024" },
    { src: "images/site28.jpg", discipline: "Voile", info: "Finale kitesurf (F) | Voile | Jeux Olympiques de Paris 2024" }
];

// Mélange de Fisher-Yates : chaque ordre a la même probabilité
function shuffle(array) {
    const copy = array.slice();
    for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
}

// Affiche 10 œuvres tirées au hasard parmi les 24
function displayRandomImages() {
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = '';

    shuffle(images).slice(0, 10).forEach(image => {
        const imgContainer = document.createElement('div');
        imgContainer.className = 'image-container';

        const imgElement = document.createElement('img');
        imgElement.src = image.src;
        imgElement.alt = image.discipline.trim();
        imgElement.loading = 'lazy';

        const caption = document.createElement('p');
        caption.textContent = `${image.discipline.trim()} - ${image.info}`;

        imgContainer.appendChild(imgElement);
        imgContainer.appendChild(caption);
        gallery.appendChild(imgContainer);
    });
}

// Consentement RGPD : la carte Google Maps (contenu tiers) n'est chargée qu'après acceptation
const CONSENT_KEY = 'cookie-consent';

function loadThirdParty() {
    const map = document.getElementById('map');
    if (map && !map.src) map.src = map.dataset.src;
}

function blockThirdParty() {
    const map = document.getElementById('map');
    if (map) map.style.display = 'none';
    document.querySelectorAll('#gallery img').forEach(img => { img.style.display = 'none'; });
}

function readConsent() {
    try { return localStorage.getItem(CONSENT_KEY); } catch (e) { return null; }
}

function saveConsent(value) {
    try { localStorage.setItem(CONSENT_KEY, value); } catch (e) { /* stockage indisponible */ }
}

document.addEventListener('DOMContentLoaded', () => {
    displayRandomImages();

    const cookieConsent = document.getElementById('cookie-consent');
    const choice = readConsent();

    if (choice === 'accepted') {
        cookieConsent.style.display = 'none';
        loadThirdParty();
    } else if (choice === 'refused') {
        cookieConsent.style.display = 'none';
        blockThirdParty();
    }

    document.getElementById('accept-cookies').onclick = () => {
        saveConsent('accepted');
        cookieConsent.style.display = 'none';
        loadThirdParty();
    };

    document.getElementById('decline-cookies').onclick = () => {
        saveConsent('refused');
        cookieConsent.style.display = 'none';
        blockThirdParty();
        alert('Vous avez refusé les cookies : la carte et les images hébergées ne seront pas affichées.');
    };
});
